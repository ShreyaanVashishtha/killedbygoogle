---
name: "Add an Obituary \U0001F480"
about: Report a dead or dying product to Killed by Google.

---

**What's the Product's Name?**

**Describe the product in a single sentence.**

**When was the product launched? Provide a specific date, if possible.**

**When was the product discontinued? Provide a specific date, if possible.**

**What type of product was it? App, Service, or Hardware?**

